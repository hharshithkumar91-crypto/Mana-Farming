import React from "react";
import TopBar from "./TopBar";
import Hero from "./Hero";
import Categories from "./Categories";
import ProductRow from "./ProductRow";
import BottomNav from "./BottomNav";

export default function App() {
  return (
    <div className="flex flex-col min-h-screen bg-bg-primary text-text-primary">
      <TopBar />
      <main className="flex-1 pt-16 pb-16">
        <Hero />
        <Categories />
        <ProductRow title="Fresh from farms today" />
        <ProductRow title="Best mandi prices" />
      </main>
      <BottomNav />
    </div>
  );
}
